//window.config="https://www.zk9x.cn/api";
window.config="https://cloud.zk9x.cn/api";
// window.config="http://192.31.10.62:8001";
//window.config="http://192.31.10.63:8001";
//window.config="http://192.31.10.58:8001";
// window.config="http://192.31.10.166:8001";